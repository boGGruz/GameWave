Heroes of Might and Magic
-------------------------

The following information supplements that found in the manual.

Movement Cost
-------------
The following terrains cost extra to move through for all heroes 
except Barbarians:

Snow   1.5 times normal cost
Swamp  1.5 times normal cost
Desert 2   times normal cost

Diagonal movement costs 1.5 times normal cost.


Recruiting Heroes
-----------------
The same two heroes are available throughout your kingdom to recruit at
any given time.  These choices change at the beginning of each new week.



Spells
------
Berzerk - Berzerk lasts as many rounds as the casting hero's spellpower, 
or until the affected troop makes an attack.  The berzerk unit will always
attack if it starts its turn next to another unit, otherwise it will move 
aimlessly.

Haste - Hasted troops speed becomes 'Very Fast' (faster than the fastest 
natural speed).


Keyboard Commands (additional)
------------------------------

Adventure Screen
----------------
Arrow Keys - Move hero in indicated direction.
Arrow Keys (with <Ctrl> held down) - Scroll screen in indicated direction.

Combat Screen
-------------
Space Bar - Skip the current troop's turn.
'A' - Auto combat.
'C' - Cast spell.
'T' - View information on the current troop.


Troubleshooting
---------------

If you are having trouble running Heroes of Might and Magic and you
are running EMM386 or memmaker try:

   1. Typing EMM386 OFF at your command prompt

      If EMM386 reports InActive then Heroes should run properly.

      Note: You will need to type EMM386 OFF everytime you reboot 
            your computer.

   2. Try REMing out EMM386 in your CONFIG.SYS:

      type the following at your command prompt and hit ENTER.

         EDIT C:\CONFIG.SYS   

            (This will edit your system configuration)

         find the line 

            DEVICE=C:\DOS\EMM386.EXE 

         or the like and add to the front of the line REM ... i.e.

            REM DEVICE=C:\DOS\EMM386.EXE

         go to the File Menu and Select Exit and answer YES to save 
         the changes.

         If you need to re-install EMM386 for any reason you can remove
         the REM at the front of the line.

      You will need to re-boot your computer for this change to take effect.


If the install program says you do not have enough free space to Install
Heroes of Might and Magic.

   1. If you are running DoubleSpace, DriveSpace, Stacker or any kind of
      disk compression:

         a. Dos reports what the disk compressor tells it to report and
            not the TRUE value of Disk Space available.

            Your must free up space to install Properly. Failure to ensure
            enough REAL space is available will result in Heroes not 
            functioning properly.

   2. If you are running from Windows or Windows 95:
         
         a. Windows tends to save the files even after they have been deleted
            or moved to the Recycle Bin.

         b. Norton Utilities also will report more Disk Space then is available
            due to the Recycle Bin and protecting deleted files.

         c. Even though Dos reports you have enough free Disk Space you
            can only use whatever space if really available.

      Fix:

         If you are running Windows 95 and Norton Utilities for Windows 95
         you must select the Recycle Bin by clicking with the Right Mouse 
         Button, then selecting Empty Norton Protected Files.

         If you are using another version of a Utilitiy that saves deleted
         files then you must discard those files as well.
   

Multi-Player Modem Game
-----------------------
In order to allow more complete configuration for modems, you must set up 
your modem in the INSTALL program before playing a modem game, using 
option 3, Change Modem Config. 


Network Installation Instructions
---------------------------------

Installation Instructions for Windows for Workgroups 3.11 Networking
--------------------------------------------------------------------

Open "Network" Program Group
Double Click "Network Setup" Icon
Click "Network" Button
Choose "Install Microsoft Windows Network"
Click "OK"
Click "Drivers"
Click "Add Adapter"
Click "Detect"
If your network adapter is not automatically detected, you should choose it
from the list of adapters.
Verify that each of the adapter card settings is correct then press "OK" for 
each one.

At this point the windows should look something like this:
	Your Network Card Name
	Microsoft NetBEUI
	IPX/SPX Compatible Transport with NetBIOS

If Microsoft NetBEUI is not the default protocol, click once on it then click 
the "Set As Default Protocol" button.
Click the "Close" button
Click the "OK" Button
Verify that your name and your computer's name are correct.  Make sure to 
choose a unique name for yourself.
Click "OK"

Windows will prompt you for the diskettes containing the necessary files for 
your network card.  When Setup is complete, click "Restart Computer" to reboot.

If your computer boots into Windows:
	From the File menu select Run.
	enter in the command box:
		SYSEDIT
	and press enter
	this will load your System Configuration Files and allow you to edit them.
	Find the AUTOEXEC.BAT window and click on it�s title bar.
	Once the Autoexec.bat is selected look for the line:
		NET START
	and change the line to read
		NET START NETBEUI

	Quit the configuration by double-clicking on the upper left box of the System 
   Configuration or by selecting Quit from the File Menu.

	It will ask to save changes, which of course you will say YES!

	Now Everytime you boot your computer it will be properly configured.	

If your computer boots into DOS:
	Type "NET START NETBEUI" and press "Enter" to load the NetBIOS driver.  You 
   should receive a message that says "The command completed successfully."  
   You will need to load the network driver each time you restart your computer.

Heroes of Might and Magic will not run from Windows 3.11 so exit Windows before 
running Heroes of Might and Magic.

Once you have loaded the network driver, run Heroes of Might and Magic and play 
a network game.


Installation Instructions for Windows 95 Networking
---------------------------------------------------

Click on the "Start" menu and choose "Settings->Control Panel."
Open the "Network" Icon
If there is a Network Card already configured in your computer, skip to the 
instructions for "Installing NetBEUI."  If the "Configuration" box is empty 
or does not include a network card, continue to the "Network Card Installation" 
Instructions.

Network Card Installation
-------------------------

Click the "Add" button.
Click on "Adapter."
Click on "Add."
Click on the name of your card's manufacturer in the "Manufacturers:" box.
Click on the name of the network adapter you are installing in the 
"Network Adapters:" box.

Click "OK."
Your "Configuration" windows should look something like this:
		Client for Microsoft Networks
		Client for NetWare Networks
		Your Network Adapter Name
		IPX/SPX Compatible Protocol
		NetBEUI

If this is correct, skip to the instructions for "Configuring NetBEUI."  
If your "Configuration" window does not contain these lines, continue to 
the "Adding Network Protocols" instructions.

Adding Network Protocols
------------------------

If the "Client for Microsoft Networks" is not installed on your computer, 
click the "Add" button.
Click "Client", then click "Add."
Select "Microsoft" in the "Manufacturers:" window then select "Client for 
Microsoft Networks" in the "Network Clients:" window.
Click "OK."
Your "Configuration" windows should look something like this:
		Client for Microsoft Networks
		Your Network Adapter Name
		IPX/SPX Compatible Protocol
		NetBEUI
If this is correct, continue to the instructions for "Configuring NetBEUI."  
If your "Configuration" window does not contain these lines, remove the 
network adapter and start over.  If that does not help, consult your manual 
or contact Microsoft Technical Support.

Configuring NetBEUI
-------------------

Double Click on "NetBEUI."
Click on the "Advanced" tab near the top of the window.
At the bottom of the window is a box marked "Set this protocol to be the 
default protocol."  If this box is not checked, click in it to add the checkmark 
then click "OK."  If there is already a checkmark in the box. then just click "OK."
Click on the "Identification" tab near the top of the windows.
Verify that the "Computer Name:" and "Workgroup:" boxes have the correct 
information in them.  Make sure you choose a unique "Computer Name:" 
for yourself.
Click "OK."
You may see a dialog box allowing you to change the hardware settings of your 
network card.  If you do, verify that all of the settings are correct and then 
click "OK."

When Windows 95 is finished copying the necessary files it will ask you to restart 
your computer.  Make sure all your other applications are closed, then click "Yes."
Congratulations!  You should now be able to play Heroes of Might and Magic on your 
network.  If you have not already installed Heroes of Might and Magic, please 
follow the "Installation for Windows 95" on the enclosed Insert Card.


Networking To and From compatibility table.
-------------------------------------------

If you want to network Heroes of Might and Magic you must
be connecting between compatible version of NETBIOS. 
Below is a chart of compatible connections.

FROM           TO
----           --

Windows 95  -  Windows 95
               Windows 3.11

Windows 3.11-  Windows 95
               Windows 3.11
               DOS

DOS         -  Windows 3.11
               DOS


Reaching New World Computing
----------------------------

- New World Computing, Inc.
  P.O. Box 4302
  Hollywood, CA 90078

  Technical Support can be reached at
   
     (818)-889-5650

  between the hours of 9am - 12noon and 2pm - 5pm PST

